//18. Write a Java program to multiply two binary numbers.
import java.util.Scanner;
class q18
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Input the first binary number: ");
int n1=sc.nextInt();
System.out.print("Input the Second binary number: ");
int n2=sc.nextInt();
/*int n1=1011;
int n2=1111;*/
int b=0,a=0,c=0,d=0;
int i=0,index=0,j=0,mult=0;
int e[]=new int[10];
while(n1!=0 && n2!=0)
{

a=n1%10;
b=n2%10;
c=(int)(c+a*Math.pow(2,i));
d=(int)(d+b*Math.pow(2,i));
n1=n1/10;
n2=n2/10;
i++;
}
mult=c*d;
while(mult!=0)
{
e[index]=mult%2;
mult=mult/2;
index++;
}
for(j=e.length-1;j>=0;j--)
{
System.out.print(e[j]);
}
}
}