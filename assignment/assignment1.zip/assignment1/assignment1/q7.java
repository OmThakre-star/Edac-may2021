//7. Write a Java program that takes a number as input and prints its multiplication table upto 10
import java.util.Scanner;
public class q7
{
 public static void main(String args[])
 {
  Scanner in=new Scanner(System.in);
     System.out.println("Input a number:");
     int num1= in.nextInt();
	 for(int i=1;i<=10;i++)
	 { 
	 System.out.println(num1+"x"+i+ "=" +(num1*i));
	 }
 }
}