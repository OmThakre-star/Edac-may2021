//1. Write a Java program to print 'Hello' on screen and then print your name on a separate line. 
public class q1
{
 public static void main(String args[])
 {
  System.out.println("Hello");
  System.out.println("Om Thakre");
 }
}