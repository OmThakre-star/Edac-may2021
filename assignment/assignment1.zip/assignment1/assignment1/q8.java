//8. Write a Java program to display the following pattern.
public class q8
{
 public static void main(String args[])
 {
  System.out.println("   j    a    v     v    a   ");
  System.out.println("   j   a a    v   v    a a  ");
  System.out.println("j  j  aaaaa    v v    aaaaa ");
  System.out.println(" jj  a     a    v    a     a");
 }
}