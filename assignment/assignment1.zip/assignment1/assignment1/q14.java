//14. Write a Java program to print an American flag on the screen. 
class q14
{
public static void main(String args[])
{
for(int i=0;i<4;i++)
{
System.out.println("* * * * * *=================================");
System.out.println(" * * * * * =================================");
}
System.out.println("* * * * * *=================================");
for(int j=0;j<6;j++)
{
System.out.println("============================================");
}
}
}