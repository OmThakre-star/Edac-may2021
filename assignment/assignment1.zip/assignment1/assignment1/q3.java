//3. Write a Java program to divide two numbers and print on the screen. 
public class q3
{
 public static void main(String args[])
 {
  System.out.println(50/3);
 }
}