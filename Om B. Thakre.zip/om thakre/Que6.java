//WAP to illustrate condition operator to find maximum among 2or 3 numbers
import java.util.Scanner;
public class Que6 
{
    public static void main(String[] args) 
    {
        int a, b, c, d;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter all three numbers:");
        a = s.nextInt();           //4
        b = s.nextInt();           //5
        c = s.nextInt();           //8
        d = c > (a > b ? a : b) ? c : ((a > b) ? a : b);
        System.out.println("Maximum Number is:"+d);      //output:8
    }
}